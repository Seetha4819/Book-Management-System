import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BookDAO dao = new BookDAO();

        while (true) {
            System.out.println("\n--- Book Management Menu ---");
            System.out.println("1. Add Book");
            System.out.println("2. View All Books");
            System.out.println("3. Update Book");
            System.out.println("4. Delete Book");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter Author: ");
                    String author = sc.nextLine();
                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();
                    dao.addBook(new Book(title, author, price));
                    break;

                case 2:
                    List<Book> books = dao.getAllBooks();
                    for (Book b : books) {
                        System.out.println(b.getId() + ". " + b.getTitle() + " by " + b.getAuthor() + " - ₹" + b.getPrice());
                    }
                    break;

                case 3:
                    System.out.print("Enter Book ID to update: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("New Title: ");
                    title = sc.nextLine();
                    System.out.print("New Author: ");
                    author = sc.nextLine();
                    System.out.print("New Price: ");
                    price = sc.nextDouble();
                    dao.updateBook(new Book(id, title, author, price));
                    break;

                case 4:
                    System.out.print("Enter Book ID to delete: ");
                    int deleteId = sc.nextInt();
                    dao.deleteBook(deleteId);
                    break;

                case 5:
                    System.out.println("Exiting program...");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
